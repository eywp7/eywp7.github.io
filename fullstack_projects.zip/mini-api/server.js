const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

let users = [
  { id: 1, name: "Ahmet", email: "ahmet@test.com" },
  { id: 2, name: "Mehmet", email: "mehmet@test.com" }
];

app.get('/', (req, res) => {
  res.send('Mini API çalışıyor!');
});

app.get('/users', (req, res) => {
  res.json(users);
});

app.post('/users', (req, res) => {
  const { name, email } = req.body;
  const newUser = { id: users.length + 1, name, email };
  users.push(newUser);
  res.status(201).json(newUser);
});

app.delete('/users/:id', (req, res) => {
  const id = parseInt(req.params.id);
  users = users.filter(user => user.id !== id);
  res.status(200).json({ message: 'Kullanıcı silindi' });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server http://localhost:${PORT} adresinde çalışıyor`));